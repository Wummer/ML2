from __future__ import division
import numpy
from matplotlib import pylab as plt
import Maria_LDA
import sunspots

"""
Part 1
""" 
#Maria_LDA
#Called when importing the file

print "*" * 45

"""
Part 2
"""
#calls file sunspots.py
#outputs 3 plots and RMS for ML
sunspots.run()