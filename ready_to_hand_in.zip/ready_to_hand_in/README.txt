Run main.py from terminal. 

Libraries needed:

numpy 
pylab
math
operator